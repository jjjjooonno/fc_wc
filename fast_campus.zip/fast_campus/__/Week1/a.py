
variable_int = 3

print(variable_int)
variable_float = 3.6
print(variable_float)

variable_string = 'hello'
print(variable_string)
print(type(variable_int))
print(type(variable_string))

variable_int_to_string = str(variable_int)
print(variable_int_to_string)